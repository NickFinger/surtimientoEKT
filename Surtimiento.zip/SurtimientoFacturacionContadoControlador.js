menuHead.controller('facturacionContadoController', ['$scope', 'servicioFacturacionContado', 'ngDialog','mensajeServicio','MenuPrincipalCabeceroFabrica',
    function($scope, servicioFacturacionContado, ngDialog, mensajeServicio, MenuPrincipalCabeceroFabrica)
    {
	
		$scope.iniciaFacturacionEPOS = function() {
		$scope.nacional = true;
		$scope.nitValido = false;
		var rfc = $scope.datosFiscales ? '' : 'XAXX010101000';
		
		if(!$scope.FacturacionEPOS){
			$scope.FacturacionEPOS = { oEntPeticionFacturaNST : { esDesgloceIVA : false, idPedido : $scope.DatosPedido.idPedido,
			oEntDatosEntradaNST : { eTipoLlamadoNST : 0, idSesion : 0, idUsuario: mensajeServicio.numEmpSinT( MenuPrincipalCabeceroFabrica.getEmpNoMH() ), ws: MenuPrincipalCabeceroFabrica.getEstacionMH()},
			oEntClienteFacturaNST : { RFCCliente: rfc , calle : '', colonia : '', cp : '', nombreCompleto : '', numeroExt : '', numeroInt : '' }
			}
			};
			if($scope.DatosPedido.EsGuardarDatosMostrador){
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.nombreCompleto = $scope.DatosPedido.DatosClienteMostrador.NombreCliente + " " + $scope.DatosPedido.DatosClienteMostrador.APaterno + " " + $scope.DatosPedido.DatosClienteMostrador.AMaterno;
			}
		}else{
			$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.RFCCliente = rfc;
		}
		};

        $scope.facturarEPOS = function() {

			if(!$scope.nitValido){
				mensajeServicio.mensajeError({titulo: 'Error', msjUsuario: "Para proceder con la factura se debe validar el N.I.T. ó C.F.", clase: 'rojo'});
				return;
			}			
			$scope.datosClienteFactura.$setSubmitted();
			if ($scope.datosClienteFactura.$valid)
            {
				var idD = mensajeServicio.indicadorEspera('Generando Factura', 'rojo');
				servicioFacturacionContado.facturacionEPOS($scope.FacturacionEPOS).then(
                    function(response) {
					    mensajeServicio.cerrarIndicadorEsperaId(idD);
						if(response.data.FacturacionEPOSResult.oEntRespuestaNST.eTipoError !== 0)
							mensajeServicio.mensajeError({titulo:'Error', msjUsuario: response.data.FacturacionEPOSResult.oEntRespuestaNST.mensajeError, clase: 'rojo'});
						else
							$scope.impresiones(response.data.FacturacionEPOSResult);
                    },
                    function(error)
                    {
                        mensajeServicio.cerrarIndicadorEsperaId(idD);
						mensajeServicio.mensajeError({titulo: 'Error', msjUsuario: "Error al generar factura", msjTecnico : error.status + " - " + error.statusText, clase: 'rojo'});
                    }
           		);
			}
		};
		
		$scope.validarNITFactura = function() {
			var frmNIT = $scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.RFCCliente;
			var frmNombre = $scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.nombreCompleto;
			if(frmNIT == "CF" && frmNombre == ""){
				mensajeServicio.mensajeError({titulo:'Error', msjUsuario: "Para el guardado de C.F. debe ingresar el nombre del Cliente.", clase: 'rojo'});
				return;
			}
            var idDnit = mensajeServicio.indicadorEspera('Validando N.I.T.', 'rojo');
			var parametrosNit = { pedido: $scope.DatosPedido.idPedido, nit: frmNIT, nombre: frmNombre, direccion: "", esMoto: false };
            servicioFacturacionContado.validaNIT(parametrosNit).then(
				function(response) {
					mensajeServicio.cerrarIndicadorEsperaId(idDnit);
					if(response.data.EsError)
						mensajeServicio.mensajeError({titulo:'Error', msjUsuario: response.data.MensajeUsuario, msjTecnico: response.data.MensajeTecnico, clase: 'rojo'});
					else{
						$scope.nitValido = true;
						if(frmNIT != "CF"){

							if(frmNIT != "" && frmNombre != ""){
                                $scope.facturarEPOS();
                            }
                            else{                           
                                $scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.nombreCompleto = response.data.NombreCliente;
                            }        
						} 
						else if(frmNIT != "" && frmNombre != ""){                         
							$scope.facturarEPOS();
                        } 
					}
				},
				function(error)
				{
					mensajeServicio.cerrarIndicadorEsperaId(idDnit);
					mensajeServicio.mensajeError({titulo: 'Error', msjUsuario: "Error al validar N.I.T.", msjTecnico : error.status + " - " + error.statusText, clase: 'rojo'});
				}
			);		
        };
				
        $scope.keyPressed = function (keyEvent) {
            if (keyEvent.keyCode == 13) {
                $scope.validarNITFactura();
            }
		};
		
		$scope.$watch('nacional', function(nacional) {
			if(!nacional && !$scope.datosFiscales && $scope.FacturacionEPOS){
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.RFCCliente = 'XEXX010101000';
			}else if(nacional && !$scope.datosFiscales && $scope.FacturacionEPOS){
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.RFCCliente = 'XAXX010101000';
			}
		});
		
		$scope.$watch('datosFiscales', function(datosFiscales) {
			if(!datosFiscales && $scope.FacturacionEPOS){
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.RFCCliente = 'XAXX010101000';
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.calle = '';
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.numeroExt = '';
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.numeroInt = '';
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.colonia = '';
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.cp = '';
			}else if(datosFiscales && $scope.FacturacionEPOS){
				$scope.FacturacionEPOS.oEntPeticionFacturaNST.oEntClienteFacturaNST.RFCCliente = '';
			}
		});
 
    }]);