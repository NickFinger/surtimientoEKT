menuHead.factory('servicioFacturacionMotos', ['$http', 'WebService', 'loggerServicios', '$q',
    function($http, WebService, loggerServicios, $q) {

        var urlBase = WebService.WS_ROUTE_FAC_MOTOS;
		var urlBaseSurtimiento  = WebService.WS_ROUTE;
		var logNombreAplicacion = "Surtimiento (Front-End)";
        var dataFactory = {};
		
		function successCallback(response) {
            loggerServicios.GuardarLogEpos(logNombreAplicacion, "-WS_OK- Respuesta: " + JSON.stringify(response));
            return response;
        };

        function errorCallback(response) {
            loggerServicios.GuardarLogEpos(logNombreAplicacion, "-WS_ERROR- Respuesta: " + JSON.stringify(response));
            return $q.reject(response);
        };

        dataFactory.conEstatusFacturacion = function(parametros) {
            return $http.get(urlBase + '/conEstatusFacturacion', {params: parametros}).then(successCallback, errorCallback);
        };
        dataFactory.conClienteITK = function(parametros) {
            return $http.get(urlBase + '/conClienteITK', {params: parametros}).then(successCallback, errorCallback);
        };
        dataFactory.conClienteEKT = function(parametros) {
            return $http.get(urlBase + '/conClienteEKT', {params: parametros}).then(successCallback, errorCallback);
        };
        dataFactory.conItalikaITK = function(parametros) {
            return $http.get(urlBase + '/conItalikaITK', {params: parametros}).then(successCallback, errorCallback);
        };
        dataFactory.conItalikaEKT = function(parametros) {
            return $http.get(urlBase + '/conItalikaEKT', {params: parametros}).then(successCallback, errorCallback);
        };
        dataFactory.ConExistBiometrico = function(parametros) {
            return $http.get(urlBase + '/ConExistBiometrico', {params: parametros}).then(successCallback, errorCallback);
        };
        dataFactory.insCliente = function(params) {
            return $http.post(urlBase + '/insCliente', params).then(successCallback, errorCallback);
        };
        dataFactory.insItalika = function(params) {
            return $http.post(urlBase + '/insItalika', params).then(successCallback, errorCallback);
        };
        dataFactory.insTerminos = function(params) {
            return $http.post(urlBase + '/insTerminos', params).then(successCallback, errorCallback);
        };
		
		dataFactory.validaNIT = function (params) {
            return $http.get(urlBaseSurtimiento + '/validaNit', { params: params }).then(successCallback, errorCallback);
        };
		
		//Motos Nuevas Marcas
		dataFactory.conClienteMNM = function(parametros) {
            return $http.get(urlBase + '/ClienteMotosNuevasMarcas', {params: parametros}).then(successCallback, errorCallback);
        };
        dataFactory.conDatosMNM = function(parametros) {
            return $http.get(urlBase + '/DatosMotosNuevasMarcas', {params: parametros}).then(successCallback, errorCallback);
        };
		//Fin De Motos Nuevas Marcas

        return dataFactory;
    }]);
